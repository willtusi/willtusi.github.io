---
name: mobile-prototype-flow
description: Iterate this workspace mobile web prototype from mockup screenshots. Use when the user sends a prototype image with feature or interaction requirements, or asks to polish the prototype UI. Not for unrelated coding.
---

# 移动端原型图迭代流程（拼豆记录 WillPD）

本工作区是一个纯静态 H5 移动端原型。用户会持续以**原型截图 + 文字规则**的方式逐步提需求。严格按"先澄清、确认后实现、再回归验证"的节奏执行。

## 项目事实（务必遵守）

- 纯静态、无框架、无构建工具，只有三个文件：`index.html`、`css/style.css`、`js/app.js`。不要引入 npm/打包/框架。
- Windows 环境，系统**没有** python / py / node / npx。本地预览只能用 PowerShell 的 HttpListener，用 `scripts/start-server.ps1` 的内容后台启动（`run_in_background: true`），预览地址 http://localhost:8080/ 。注意：直接在当前 shell 用**单引号**跑整段命令，不要再嵌套一层 `powershell -Command`（双引号会被外层吞掉导致解析失败）。
- 数据全部存 localStorage：`pindou_stocks_v1`（各豆色库存对象，如 `{A1:70}`）、`pindou_records_v1`（拼豆消耗记录数组）。
- 色系与豆色数量固定写死在 `SERIES_CONFIG`：A26、B32、C29、D26、E24、F25、G21、H23、M15。
- 页面为同一 HTML 内的 section 切换：home（首页）、pool（豆池）、config（豆色配置，豆池子页）、detail（记录详情，首页子页）；底部 Tab 只有"首页/豆池"。

## 标准流程

1. **看图理解**：必要时先 `ExperienceRecall` 查相似问题（动态表单默认值残留、库存批量修改、UI 美化澄清等是高频坑）。
2. **先澄清，不抢跑**：用户明确说"先把疑问告诉我，确认后再输出"时，绝对不要先写代码。用一次 `AskUserQuestion`（1–4 问）把所有歧义点一次性问清；每问给 2–4 个选项，把推荐项放第一个并标注"（推荐）"。图片看不清（如纯灰/发送失败）时必须指出并请用户重发，不要臆造。
3. **确认后规划**：用 TodoWrite 拆步骤，再动手。
4. **实现约定**：
   - 列表/网格一律数据驱动渲染；状态展示节点带稳定 `data-*` 标识，更新只改 `textContent`，不整体重绘带事件的结构。
   - 动态列表用事件委托 + `closest()`；卡片主点击区与内部按钮点击要隔离（按钮内 `stopPropagation`）。
   - 表单类弹层每次打开都显式重置状态，避免上一次输入/选择残留。
   - 校验失败用吐司，3 秒自动关闭（文案沿用用户给的原文）。
   - 纯美化需求默认**只改 CSS**，不改 HTML 类名结构与 JS；动 UI 风格前先澄清方向（已确定：现代柔和卡片风、统一紫色主色、浅色模式）。
5. **视觉规范**（CSS 变量已在 `:root`，改样式时复用，不要硬编码新颜色）：
   - 主色 `--primary:#8b7cf6` / `--primary-deep:#7565ef`，淡紫底 `--primary-soft:#efedff`
   - 页面底 `--bg:#f5f5f8`，卡片白底 + 柔和投影 `--shadow-card`，去粗黑描边、大圆角
   - 主按钮紫色渐变胶囊 + 投影；Tab 栏白色毛玻璃胶囊；弹窗白底圆角 + 毛玻璃遮罩
6. **回归验证**：实现后用 `browser_use` 子代理走查关键路径并截图；子代理预算有限时，把多条断言合并、预置数据用 `browser_evaluate` 直接写 localStorage 再 reload。自己再 `Read` 关键截图核对视觉，确认无文字与背景同色、无布局遮挡。最后检查控制台无报错、原有交互无回归。
7. **汇报**：用简洁中文总结改动，文件用可点击绝对链接引用，说明预览地址与验证结果。

## 已确认的业务规则（改相关功能时保持一致）

- 豆色配置页：进入**不默认选中**任何色号；点格选中、再点同一格直接取消（允许 0 选中，无"至少保留 1 个"限制）；可累加多选；全选联动（全选状态再点=全部清空）；0 选中时数量卡显示"请选择豆色"、保存拦截提示"请先选择豆色"；单选显示该色号库存，多选显示选中项库存总和；输入为非负整数；多选保存是把每个选中色号库存统一覆盖为输入值；确认后返回豆池，色系数量 = 其下所有豆色库存之和。
- 创建拼豆记录抽屉：豆盘名称最多 10 字（超出截断+吐司）；保存立即扣减豆池库存；禁止重复色号；名称和每行数量都必填正整数；消耗超库存吐司拦截；记录显示本地创建日期（YYYY年M月D日）。
- 记录支持左滑删除（Pointer Events 实现，触屏和鼠标拖拽都要可用），删除暂不返还库存。
- 记录详情每个色号显示"已消耗"和"剩余库存"，剩余读豆池最新库存。
